#!/bin/bash

# Aghan Promoters VPS Deployment Script
# Run this script on your VPS after uploading files

set -e

APP_DIR="/var/www/aghan-promoters"
DOMAIN="aghan.techminds.info"

echo "=== Aghan Promoters Deployment ==="

# Create app directory
sudo mkdir -p $APP_DIR
cd $APP_DIR

# Install dependencies
echo "Installing dependencies..."
npm install --production

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating .env file..."
    cat > .env << EOF
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/aghan_promoters
SESSION_SECRET=$(openssl rand -base64 32)
NODE_ENV=production
PORT=3001
EOF
    echo "Please edit .env file with your database credentials!"
fi

# Setup Nginx
echo "Setting up Nginx..."
sudo cp deploy/nginx-aghan.conf /etc/nginx/sites-available/$DOMAIN
sudo ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Start with PM2
echo "Starting application with PM2..."
pm2 delete aghan-promoters 2>/dev/null || true
pm2 start dist/index.cjs --name "aghan-promoters"
pm2 save

echo "=== Deployment Complete ==="
echo ""
echo "Next steps:"
echo "1. Edit .env file: nano $APP_DIR/.env"
echo "2. Create database: sudo -u postgres createdb aghan_promoters"
echo "3. Get SSL: sudo certbot --nginx -d $DOMAIN"
echo "4. Restart app: pm2 restart aghan-promoters"

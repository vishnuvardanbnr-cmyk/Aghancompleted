# Aghan Promoters - VPS Deployment Guide

## Quick Deployment Steps

### 1. On Your Local Machine (or download from Replit)

Download all project files and upload to your VPS:

```bash
# Upload via SCP (from your local machine)
scp -r . root@159.89.173.145:/var/www/aghan-promoters/
```

Or use Git:
```bash
# On VPS
cd /var/www
git clone YOUR_GIT_REPO_URL aghan-promoters
cd aghan-promoters
```

### 2. On Your VPS (159.89.173.145)

```bash
# SSH into your VPS
ssh root@159.89.173.145

# Go to app directory
cd /var/www/aghan-promoters

# Make setup script executable and run
chmod +x deploy/setup.sh
./deploy/setup.sh
```

### 3. Configure Database

```bash
# Create PostgreSQL database
sudo -u postgres createdb aghan_promoters

# Edit environment variables
nano /var/www/aghan-promoters/.env
```

Update DATABASE_URL with your actual PostgreSQL credentials:
```
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/aghan_promoters
```

### 4. Restart Application

```bash
pm2 restart aghan-promoters
```

### 5. Get SSL Certificate

```bash
sudo certbot --nginx -d aghan.techminds.info
```

### 6. Point Your Domain

Add DNS A record in your domain provider:
- Type: A
- Name: aghan
- Value: 159.89.173.145
- TTL: Auto

## Useful Commands

```bash
# View logs
pm2 logs aghan-promoters

# Restart app
pm2 restart aghan-promoters

# Check status
pm2 status

# Check Nginx
sudo nginx -t
sudo systemctl status nginx
```

## Environment Variables Required

| Variable | Description |
|----------|-------------|
| DATABASE_URL | PostgreSQL connection string |
| SESSION_SECRET | Random secret for sessions |
| NODE_ENV | Set to "production" |
| PORT | Server port (default: 3001) |

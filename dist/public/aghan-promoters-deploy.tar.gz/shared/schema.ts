
import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session table for express-session (managed by connect-pg-simple)
export const session = pgTable("session", {
  sid: varchar("sid").primaryKey(),
  sess: text("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

// Enums
export const boardTypeEnum = pgEnum("board_type", ["EV", "SILVER", "GOLD", "PLATINUM", "DIAMOND", "KING"]);
export const transactionTypeEnum = pgEnum("transaction_type", ["DEPOSIT", "WITHDRAWAL", "REFERRAL_INCOME", "LEVEL_INCOME", "BOARD_ENTRY", "BOARD_COMPLETION", "ADMIN_ADJUSTMENT"]);
export const transactionStatusEnum = pgEnum("transaction_status", ["PENDING", "COMPLETED", "REJECTED"]);
export const rebirthStatusEnum = pgEnum("rebirth_status", ["ACTIVE", "PROMOTED", "COMPLETED"]);
export const accountRoleEnum = pgEnum("account_role", ["MOTHER", "SUB"]);

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  mobile: text("mobile").notNull(),
  sponsorId: integer("sponsor_id"), // References users.id
  referralCode: text("referral_code").notNull().unique(),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Wallets Table
export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  mainBalance: decimal("main_balance", { precision: 12, scale: 2 }).default("0").notNull(),
  rebirthBalance: decimal("rebirth_balance", { precision: 12, scale: 2 }).default("0").notNull(), // For auto-entry to Silver
  totalEarnings: decimal("total_earnings", { precision: 12, scale: 2 }).default("0").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Boards Table (Tracks user's progress in different boards)
export const boards = pgTable("boards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: boardTypeEnum("type").notNull(),
  status: text("status").default("ACTIVE"), // ACTIVE, COMPLETED
  isFromSubAccount: boolean("is_from_sub_account").default(false), // If entry is from rebirth sub-account (special income rules)
  sourceRebirthAccountId: integer("source_rebirth_account_id"), // Which rebirth account paid for this entry
  joinedAt: timestamp("joined_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Matrix Positions (Who is under whom in a specific board context)
export const matrixPositions = pgTable("matrix_positions", {
  id: serial("id").primaryKey(),
  boardId: integer("board_id").notNull().references(() => boards.id), // The specific board instance
  userId: integer("user_id").notNull().references(() => users.id),
  parentId: integer("parent_id").references(() => users.id), // Immediate uploader in the matrix
  position: integer("position"), // 1-6 for EV board
  level: integer("level").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transactions Table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  type: transactionTypeEnum("type").notNull(),
  status: transactionStatusEnum("status").default("COMPLETED"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Withdrawals Request Table
export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  status: transactionStatusEnum("status").default("PENDING"),
  bankDetails: text("bank_details"),
  requestedAt: timestamp("requested_at").defaultNow(),
  processedAt: timestamp("processed_at"),
});

// Notifications Table (Admin posts to all users)
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// User notification read status
export const userNotifications = pgTable("user_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  notificationId: integer("notification_id").notNull().references(() => notifications.id),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at"),
});

// Rebirth Accounts Table (Per-board rebirth sub-accounts with mother/sub hierarchy)
export const rebirthAccounts = pgTable("rebirth_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  boardType: boardTypeEnum("board_type").notNull(),
  cycle: integer("cycle").default(1).notNull(),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0").notNull(),
  threshold: decimal("threshold", { precision: 12, scale: 2 }).notNull(),
  nextBoardType: boardTypeEnum("next_board_type"),
  status: rebirthStatusEnum("status").default("ACTIVE"),
  accountRole: accountRoleEnum("account_role").default("MOTHER"),
  parentAccountId: integer("parent_account_id"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  promotedAt: timestamp("promoted_at"),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  sponsor: one(users, {
    fields: [users.sponsorId],
    references: [users.id],
    relationName: "referrals"
  }),
  referrals: many(users, { relationName: "referrals" }),
  wallet: one(wallets, {
    fields: [users.id],
    references: [wallets.userId],
  }),
  boards: many(boards),
  transactions: many(transactions),
}));

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, {
    fields: [wallets.userId],
    references: [users.id],
  }),
}));

export const boardsRelations = relations(boards, ({ one, many }) => ({
  user: one(users, {
    fields: [boards.userId],
    references: [users.id],
  }),
  positions: many(matrixPositions),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertWalletSchema = createInsertSchema(wallets).omit({ id: true, updatedAt: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Wallet = typeof wallets.$inferSelect;
export type Board = typeof boards.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type RebirthAccount = typeof rebirthAccounts.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type UserNotification = typeof userNotifications.$inferSelect;

// Auth Types
export type LoginRequest = {
  username: string;
  password: string;
};

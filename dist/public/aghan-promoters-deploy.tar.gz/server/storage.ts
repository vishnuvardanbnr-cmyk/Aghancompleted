
import { users, wallets, boards, matrixPositions, transactions, withdrawals, rebirthAccounts, notifications, userNotifications, type User, type InsertUser, type Wallet, type Board, type Transaction, type RebirthAccount, type Notification, type UserNotification } from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, count, asc, isNull, desc } from "drizzle-orm";

// Board configuration
export const BOARD_CONFIG: Record<string, { entry: number; gst: number; company?: number; directSponsor?: number; levelIncome: number; levels: number }> = {
  EV: { entry: 5900, gst: 900, company: 3900, directSponsor: 500, levelIncome: 150, levels: 4 },
  SILVER: { entry: 5900, gst: 900, levelIncome: 500, levels: 6 },
  GOLD: { entry: 10000, gst: 0, levelIncome: 500, levels: 6 },
  PLATINUM: { entry: 20000, gst: 0, levelIncome: 500, levels: 6 },
  DIAMOND: { entry: 50000, gst: 0, levelIncome: 500, levels: 6 },
  KING: { entry: 100000, gst: 0, levelIncome: 500, levels: 6 },
};

// Board sequence for progression
export const BOARD_SEQUENCE = ["EV", "SILVER", "GOLD", "PLATINUM", "DIAMOND", "KING"];

function getNextBoard(currentBoard: string): string | null {
  const index = BOARD_SEQUENCE.indexOf(currentBoard);
  if (index === -1 || index === BOARD_SEQUENCE.length - 1) return null;
  return BOARD_SEQUENCE[index + 1];
}

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
  getReferrals(userId: number): Promise<User[]>;
  getDirectReferralCount(userId: number): Promise<number>;

  // Wallet
  getWallet(userId: number): Promise<Wallet | undefined>;
  createWallet(userId: number): Promise<Wallet>;
  updateWallet(userId: number, updates: Partial<Wallet>): Promise<Wallet>;
  addToMainWallet(userId: number, amount: number, description: string): Promise<void>;
  addToRebirthWallet(userId: number, amount: number, description: string): Promise<void>;
  createTransaction(transaction: any): Promise<Transaction>;
  getTransactions(userId: number): Promise<Transaction[]>;

  // Boards
  getBoard(userId: number, type: string): Promise<Board | undefined>;
  getUserBoards(userId: number): Promise<Board[]>;
  createBoard(userId: number, type: string): Promise<Board>;
  getMatrixPositions(boardId: number): Promise<any[]>;
  getMatrixChildrenCount(parentId: number, boardType: string): Promise<number>;
  getMatrixChildren(parentId: number, boardType: string): Promise<any[]>;
  findPlacementParent(sponsorId: number, boardType: string): Promise<number>;
  addToMatrix(boardId: number, userId: number, parentId: number | null, position: number, level: number): Promise<void>;
  getUplineChain(userId: number, boardType: string, maxLevels: number): Promise<number[]>;
  
  // Board Operations
  joinBoard(userId: number, boardType: string): Promise<{ success: boolean; message: string }>;
  checkAndPromoteBoard(userId: number, boardType: string): Promise<void>;
  updateBoardStatus(userId: number, boardType: string, status: string): Promise<void>;
  
  // Withdrawal
  createWithdrawal(userId: number, amount: number, bankDetails: string): Promise<any>;
  
  // Rebirth Accounts
  getRebirthAccounts(userId: number): Promise<RebirthAccount[]>;
  getRebirthAccount(userId: number, boardType: string): Promise<RebirthAccount | undefined>;
  getActiveRebirthAccount(userId: number, boardType: string): Promise<RebirthAccount | undefined>;
  createRebirthAccount(userId: number, boardType: string, threshold: number, nextBoardType: string | null, role?: "MOTHER" | "SUB", parentAccountId?: number | null, initialBalance?: number): Promise<RebirthAccount>;
  createSubAccountFromMother(motherAccountId: number, transferAmount?: number): Promise<RebirthAccount>;
  addToRebirthAccount(userId: number, boardType: string, amount: number, description: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.referralCode, code));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getReferrals(userId: number): Promise<User[]> {
    return await db.select().from(users).where(eq(users.sponsorId, userId));
  }

  async getDirectReferralCount(userId: number): Promise<number> {
    const result = await db.select({ count: count() }).from(users).where(eq(users.sponsorId, userId));
    return result[0]?.count || 0;
  }

  async getActiveDirectReferralCount(userId: number): Promise<number> {
    // Count direct referrals who have joined the EV board (active members)
    const result = await db
      .select({ count: count() })
      .from(users)
      .innerJoin(boards, eq(users.id, boards.userId))
      .where(and(
        eq(users.sponsorId, userId),
        eq(boards.type, "EV")
      ));
    return result[0]?.count || 0;
  }

  async getWallet(userId: number): Promise<Wallet | undefined> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId));
    return wallet;
  }

  async createWallet(userId: number): Promise<Wallet> {
    // Give Rs.5900 initial balance for testing
    const [wallet] = await db.insert(wallets).values({ 
      userId,
      mainBalance: "5900"
    }).returning();
    return wallet;
  }

  async updateWallet(userId: number, updates: Partial<Wallet>): Promise<Wallet> {
    const [wallet] = await db.update(wallets).set(updates).where(eq(wallets.userId, userId)).returning();
    return wallet;
  }

  async addToMainWallet(userId: number, amount: number, description: string): Promise<void> {
    const wallet = await this.getWallet(userId);
    if (!wallet) return;
    
    const newBalance = Number(wallet.mainBalance) + amount;
    const newTotal = Number(wallet.totalEarnings) + amount;
    
    await this.updateWallet(userId, { 
      mainBalance: newBalance.toString(),
      totalEarnings: newTotal.toString()
    });
    
    await this.createTransaction({
      userId,
      amount: amount.toString(),
      type: "REFERRAL_INCOME",
      description,
      status: "COMPLETED"
    });
  }

  async addToRebirthWallet(userId: number, amount: number, description: string): Promise<void> {
    const wallet = await this.getWallet(userId);
    if (!wallet) return;
    
    const newBalance = Number(wallet.rebirthBalance) + amount;
    const newTotal = Number(wallet.totalEarnings) + amount;
    
    await this.updateWallet(userId, { 
      rebirthBalance: newBalance.toString(),
      totalEarnings: newTotal.toString()
    });
    
    await this.createTransaction({
      userId,
      amount: amount.toString(),
      type: "LEVEL_INCOME",
      description,
      status: "COMPLETED"
    });
  }

  async createTransaction(transaction: any): Promise<Transaction> {
    const [txn] = await db.insert(transactions).values(transaction).returning();
    return txn;
  }

  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(sql`${transactions.createdAt} DESC`);
  }

  async getBoard(userId: number, type: string): Promise<Board | undefined> {
    const [board] = await db.select().from(boards).where(and(eq(boards.userId, userId), eq(boards.type, type as any)));
    return board;
  }
  
  async isBoardFromSubAccount(userId: number, boardType: string): Promise<boolean> {
    const board = await this.getBoard(userId, boardType);
    return board?.isFromSubAccount === true;
  }

  async getUserBoards(userId: number): Promise<Board[]> {
    return await db.select().from(boards).where(eq(boards.userId, userId));
  }

  async createBoard(userId: number, type: string, isFromSubAccount: boolean = false, sourceRebirthAccountId: number | null = null): Promise<Board> {
    const [board] = await db.insert(boards).values({ 
      userId, 
      type: type as any,
      isFromSubAccount,
      sourceRebirthAccountId
    }).returning();
    return board;
  }

  async getMatrixPositions(boardId: number): Promise<any[]> {
    // This needs to fetch the positions for a specific board type context
    // For simplicity, we just return all positions linked to this board instance
    return await db.select().from(matrixPositions).where(eq(matrixPositions.boardId, boardId));
  }

  async getMatrixChildrenCount(parentId: number, boardType: string): Promise<number> {
    // Count how many direct children this parent has in the given board type
    const result = await db
      .select({ count: count() })
      .from(matrixPositions)
      .innerJoin(boards, eq(matrixPositions.boardId, boards.id))
      .where(and(
        eq(matrixPositions.parentId, parentId),
        eq(boards.type, boardType as any)
      ));
    return result[0]?.count || 0;
  }

  async getMatrixChildren(parentId: number, boardType: string): Promise<any[]> {
    // Get all direct children in the matrix with their user details
    const result = await db
      .select({
        id: users.id,
        username: users.username,
        fullName: users.fullName,
        position: matrixPositions.position,
        level: matrixPositions.level,
      })
      .from(matrixPositions)
      .innerJoin(boards, eq(matrixPositions.boardId, boards.id))
      .innerJoin(users, eq(matrixPositions.userId, users.id))
      .where(and(
        eq(matrixPositions.parentId, parentId),
        eq(boards.type, boardType as any)
      ))
      .orderBy(asc(matrixPositions.position));
    return result;
  }

  async findPlacementParent(sponsorId: number, boardType: string): Promise<number> {
    // First Come First Fill: Find where to place new user
    // 1. Check if sponsor has less than 6 children - place under sponsor
    // 2. Otherwise, BFS to find first person with available slot
    
    const sponsorChildCount = await this.getMatrixChildrenCount(sponsorId, boardType);
    if (sponsorChildCount < 6) {
      return sponsorId;
    }
    
    // BFS to find first available slot
    const queue: number[] = [sponsorId];
    const visited = new Set<number>();
    
    while (queue.length > 0) {
      const currentId = queue.shift()!;
      if (visited.has(currentId)) continue;
      visited.add(currentId);
      
      // Get children of current user in this board
      const children = await db
        .select({ userId: matrixPositions.userId })
        .from(matrixPositions)
        .innerJoin(boards, eq(matrixPositions.boardId, boards.id))
        .where(and(
          eq(matrixPositions.parentId, currentId),
          eq(boards.type, boardType as any)
        ))
        .orderBy(asc(matrixPositions.position));
      
      if (children.length < 6) {
        return currentId;
      }
      
      // Add children to queue for next level search
      for (const child of children) {
        if (!visited.has(child.userId)) {
          queue.push(child.userId);
        }
      }
    }
    
    // Fallback to sponsor if nothing found
    return sponsorId;
  }

  async addToMatrix(boardId: number, userId: number, parentId: number | null, position: number, level: number): Promise<void> {
    await db.insert(matrixPositions).values({
      boardId,
      userId,
      parentId: parentId,
      position,
      level
    });
  }

  async getUplineChain(userId: number, boardType: string, maxLevels: number): Promise<number[]> {
    // Get the upline chain (parent, grandparent, etc.) for level income distribution
    const upline: number[] = [];
    let currentUserId = userId;
    
    for (let i = 0; i < maxLevels; i++) {
      // Find parent in matrix for this board type
      const result = await db
        .select({ parentId: matrixPositions.parentId })
        .from(matrixPositions)
        .innerJoin(boards, eq(matrixPositions.boardId, boards.id))
        .where(and(
          eq(matrixPositions.userId, currentUserId),
          eq(boards.type, boardType as any)
        ))
        .limit(1);
      
      if (result.length === 0 || !result[0].parentId) break;
      
      upline.push(result[0].parentId);
      currentUserId = result[0].parentId;
    }
    
    return upline;
  }

  async joinBoard(userId: number, boardType: string): Promise<{ success: boolean; message: string }> {
    const config = BOARD_CONFIG[boardType as keyof typeof BOARD_CONFIG];
    if (!config) {
      return { success: false, message: "Invalid board type" };
    }

    // Check if user already in this board
    const existing = await this.getBoard(userId, boardType);
    if (existing) {
      return { success: false, message: "Already in this board" };
    }

    // Get user and their sponsor
    const user = await this.getUser(userId);
    if (!user) {
      return { success: false, message: "User not found" };
    }

    // Check wallet balance (for non-EV boards or if not auto-entry)
    const wallet = await this.getWallet(userId);
    if (!wallet) {
      return { success: false, message: "Wallet not found" };
    }

    if (boardType === "EV") {
      // EV Board: Deduct from main wallet
      if (Number(wallet.mainBalance) < config.entry) {
        return { success: false, message: "Insufficient balance" };
      }
      
      // Deduct entry fee
      await this.updateWallet(userId, {
        mainBalance: (Number(wallet.mainBalance) - config.entry).toString()
      });
      
      await this.createTransaction({
        userId,
        amount: config.entry.toString(),
        type: "BOARD_ENTRY",
        description: `EV Board entry fee`,
        status: "COMPLETED"
      });
    }

    // Create board entry
    const board = await this.createBoard(userId, boardType);

    // Find placement parent (First Come First Fill)
    // Root users (no sponsor) have null parentId
    let placementParentId: number | null = null;
    if (user.sponsorId) {
      placementParentId = await this.findPlacementParent(user.sponsorId, boardType);
    }

    // Get position under parent
    const siblingCount = placementParentId ? await this.getMatrixChildrenCount(placementParentId, boardType) : 0;
    const position = siblingCount + 1;

    // Calculate level in tree
    let level = 1;
    if (placementParentId && placementParentId !== user.sponsorId) {
      level = 2; // Spillover placement
    }

    // Add to matrix (parentId can be null for root users)
    await this.addToMatrix(board.id, userId, placementParentId, position, level);

    // Check if parent's board is now complete (6/6) and promote them
    if (placementParentId) {
      await this.checkAndPromoteBoard(placementParentId, boardType);
    }

    // Distribute income for EV Board
    if (boardType === "EV" && user.sponsorId) {
      // Direct sponsor income - Rs.500 to Main Wallet
      await this.addToMainWallet(
        user.sponsorId, 
        config.directSponsor || 500, 
        `Direct sponsor income from ${user.fullName}`
      );

      // Level income - Rs.150 x 4 levels to Rebirth Wallet or Sub-Account
      const upline = await this.getUplineChain(userId, boardType, config.levels);
      for (let i = 0; i < upline.length && i < config.levels; i++) {
        // Check if upline user has a rebirth sub-account for this board type
        // (meaning they've already upgraded past this board)
        const subAccount = await this.getRebirthAccount(upline[i], boardType);
        
        if (subAccount) {
          // Route to rebirth sub-account
          await this.addToRebirthAccount(
            upline[i],
            boardType,
            config.levelIncome,
            `Level ${i + 1} income from ${user.fullName}`
          );
        } else {
          // Route to regular rebirth wallet (for initial Silver entry)
          await this.addToRebirthWallet(
            upline[i],
            config.levelIncome,
            `Level ${i + 1} income from ${user.fullName}`
          );
          
          // Check if rebirth wallet reached 5900 for auto Silver entry
          const uplineWallet = await this.getWallet(upline[i]);
          if (uplineWallet && Number(uplineWallet.rebirthBalance) >= 5900) {
            const existingSilver = await this.getBoard(upline[i], "SILVER");
            if (!existingSilver) {
              // Deduct from rebirth wallet
              await this.updateWallet(upline[i], {
                rebirthBalance: (Number(uplineWallet.rebirthBalance) - 5900).toString()
              });
              
              // Create Silver board entry
              const silverBoard = await this.createBoard(upline[i], "SILVER");
              
              // Find placement parent for Silver board
              const uplineUser = await this.getUser(upline[i]);
              let silverPlacementParent: number | null = null;
              if (uplineUser?.sponsorId) {
                silverPlacementParent = await this.findPlacementParent(uplineUser.sponsorId, "SILVER");
              }
              
              // Get position and add to matrix
              const silverSiblingCount = silverPlacementParent ? await this.getMatrixChildrenCount(silverPlacementParent, "SILVER") : 0;
              await this.addToMatrix(silverBoard.id, upline[i], silverPlacementParent, silverSiblingCount + 1, 1);
              
              // Create transaction for Silver auto-entry
              await this.createTransaction({
                userId: upline[i],
                amount: "5900",
                type: "BOARD_ENTRY",
                description: "Auto-entry to Silver Board (Rebirth)",
                status: "COMPLETED"
              });
              
              // Create EV rebirth sub-account for further level income tracking
              const nextAfterSilver = getNextBoard("SILVER");
              const threshold = nextAfterSilver ? BOARD_CONFIG[nextAfterSilver].entry : 100000;
              await this.createRebirthAccount(upline[i], "EV", threshold, nextAfterSilver);
            }
          }
        }
      }
    }

    // Distribute level income for non-EV boards (Silver, Gold, Platinum, Diamond, King)
    // For boards from SUB accounts: direct sponsor goes to company, level income placement-based (normal)
    if (boardType !== "EV") {
      // Check if the joining user's board is from a sub-account
      // If so, direct sponsor income goes to company (skipped), but level income still distributed normally
      const isJoinerFromSubAccount = await this.isBoardFromSubAccount(userId, boardType);
      
      // For non-EV boards with direct sponsor income configured
      // If joining user's board is from a sub-account, divert direct sponsor to company
      if (isJoinerFromSubAccount && user.sponsorId && config.directSponsor) {
        // Direct sponsor income diverted to company - logged for transparency
        await this.createTransaction({
          userId: user.sponsorId,
          amount: "0",
          type: "REFERRAL_INCOME",
          description: `Direct sponsor income Rs.${config.directSponsor} from ${user.fullName} (${boardType}) - Diverted to Company (Sub-Account Entry)`,
          status: "COMPLETED"
        });
      } else if (user.sponsorId && config.directSponsor) {
        // Normal direct sponsor income distribution
        await this.addToMainWallet(
          user.sponsorId,
          config.directSponsor,
          `Direct sponsor income from ${user.fullName} (${boardType})`
        );
      }
      
      // Level income ALWAYS distributed normally (placement-based) regardless of sub-account origin
      const upline = await this.getUplineChain(userId, boardType, config.levels);
      for (let i = 0; i < upline.length && i < config.levels; i++) {
        // Check if upline user has a rebirth sub-account for this board type
        const subAccount = await this.getRebirthAccount(upline[i], boardType);
        
        if (subAccount) {
          // Route to rebirth sub-account
          await this.addToRebirthAccount(
            upline[i],
            boardType,
            config.levelIncome,
            `Level ${i + 1} income from ${user.fullName}`
          );
        } else {
          // Route to main rebirth wallet (accumulates for next board entry)
          await this.addToRebirthWallet(
            upline[i],
            config.levelIncome,
            `Level ${i + 1} income from ${user.fullName} (${boardType})`
          );
        }
      }
    }

    return { success: true, message: `Successfully joined ${boardType} Board` };
  }

  async createWithdrawal(userId: number, amount: number, bankDetails: string): Promise<any> {
    const [w] = await db.insert(withdrawals).values({ userId, amount: amount as any, bankDetails }).returning();
    return w;
  }

  async updateBoardStatus(userId: number, boardType: string, status: string): Promise<void> {
    await db.update(boards)
      .set({ status: status as any })
      .where(and(
        eq(boards.userId, userId),
        eq(boards.type, boardType as any)
      ));
  }

  async checkAndPromoteBoard(userId: number, boardType: string): Promise<void> {
    const childCount = await this.getMatrixChildrenCount(userId, boardType);
    
    if (childCount >= 6) {
      await this.updateBoardStatus(userId, boardType, "COMPLETED");
      
      const nextBoard = getNextBoard(boardType);
      if (nextBoard) {
        const existingNext = await this.getBoard(userId, nextBoard);
        if (!existingNext) {
          const nextConfig = BOARD_CONFIG[nextBoard];
          const wallet = await this.getWallet(userId);
          
          if (wallet && Number(wallet.rebirthBalance) >= nextConfig.entry) {
            await this.updateWallet(userId, {
              rebirthBalance: (Number(wallet.rebirthBalance) - nextConfig.entry).toString()
            });
            
            const newBoard = await this.createBoard(userId, nextBoard);
            
            const user = await this.getUser(userId);
            let placementParent: number | null = null;
            if (user?.sponsorId) {
              placementParent = await this.findPlacementParent(user.sponsorId, nextBoard);
            }
            
            const siblingCount = placementParent ? await this.getMatrixChildrenCount(placementParent, nextBoard) : 0;
            await this.addToMatrix(newBoard.id, userId, placementParent, siblingCount + 1, 1);
            
            await this.createTransaction({
              userId,
              amount: nextConfig.entry.toString(),
              type: "BOARD_ENTRY",
              description: `Auto-promotion to ${nextBoard} Board`,
              status: "COMPLETED"
            });

            // Create rebirth sub-account for the completed board
            // When user upgrades from EV to Silver, create sub-account for EV with Silver threshold
            const nextNextBoard = getNextBoard(nextBoard);
            const threshold = nextNextBoard ? BOARD_CONFIG[nextNextBoard].entry : 100000;
            await this.createRebirthAccount(userId, boardType, threshold, nextNextBoard);
          }
        }
      }
    }
  }

  // Rebirth Account Methods
  async getRebirthAccounts(userId: number): Promise<RebirthAccount[]> {
    return await db.select().from(rebirthAccounts)
      .where(eq(rebirthAccounts.userId, userId))
      .orderBy(desc(rebirthAccounts.createdAt));
  }

  async getRebirthAccount(userId: number, boardType: string): Promise<RebirthAccount | undefined> {
    // Get the ACTIVE account (preferably SUB account if exists, otherwise MOTHER)
    const [account] = await db.select().from(rebirthAccounts)
      .where(and(
        eq(rebirthAccounts.userId, userId),
        eq(rebirthAccounts.boardType, boardType as any),
        eq(rebirthAccounts.status, "ACTIVE"),
        eq(rebirthAccounts.isActive, true)
      ));
    return account;
  }
  
  async getActiveRebirthAccount(userId: number, boardType: string): Promise<RebirthAccount | undefined> {
    // Get the currently active account for receiving income
    const [subAccount] = await db.select().from(rebirthAccounts)
      .where(and(
        eq(rebirthAccounts.userId, userId),
        eq(rebirthAccounts.boardType, boardType as any),
        eq(rebirthAccounts.accountRole, "SUB"),
        eq(rebirthAccounts.isActive, true)
      ));
    if (subAccount) return subAccount;
    
    // Fallback to MOTHER account if no active SUB
    const [motherAccount] = await db.select().from(rebirthAccounts)
      .where(and(
        eq(rebirthAccounts.userId, userId),
        eq(rebirthAccounts.boardType, boardType as any),
        eq(rebirthAccounts.accountRole, "MOTHER"),
        eq(rebirthAccounts.isActive, true)
      ));
    return motherAccount;
  }

  async createRebirthAccount(userId: number, boardType: string, threshold: number, nextBoardType: string | null, role: "MOTHER" | "SUB" = "MOTHER", parentAccountId: number | null = null, initialBalance: number = 0): Promise<RebirthAccount> {
    // Check if there's an existing account to determine cycle number
    const existingAccounts = await db.select().from(rebirthAccounts)
      .where(and(
        eq(rebirthAccounts.userId, userId),
        eq(rebirthAccounts.boardType, boardType as any)
      ))
      .orderBy(desc(rebirthAccounts.cycle));
    
    const nextCycle = existingAccounts.length > 0 ? existingAccounts[0].cycle + 1 : 1;
    
    const [account] = await db.insert(rebirthAccounts).values({
      userId,
      boardType: boardType as any,
      cycle: nextCycle,
      balance: initialBalance.toString(),
      threshold: threshold.toString(),
      nextBoardType: nextBoardType as any,
      status: "ACTIVE",
      accountRole: role,
      parentAccountId: parentAccountId,
      isActive: true
    }).returning();
    
    return account;
  }
  
  async createSubAccountFromMother(motherAccountId: number, transferAmount: number = 5900): Promise<RebirthAccount> {
    // Get the mother account
    const [mother] = await db.select().from(rebirthAccounts)
      .where(eq(rebirthAccounts.id, motherAccountId));
    
    if (!mother) {
      throw new Error("Mother account not found");
    }
    
    // Mark mother as no longer active (but not PROMOTED, just inactive)
    await db.update(rebirthAccounts)
      .set({ isActive: false })
      .where(eq(rebirthAccounts.id, motherAccountId));
    
    // Create a new SUB account with the transfer amount
    const nextNextBoard = getNextBoard(mother.nextBoardType || mother.boardType);
    const threshold = nextNextBoard ? BOARD_CONFIG[nextNextBoard].entry : 100000;
    
    const subAccount = await this.createRebirthAccount(
      mother.userId,
      mother.boardType,
      threshold,
      nextNextBoard,
      "SUB",
      motherAccountId,
      transferAmount
    );
    
    // Create transaction for the transfer
    await this.createTransaction({
      userId: mother.userId,
      amount: transferAmount.toString(),
      type: "BOARD_ENTRY",
      description: `Rs.${transferAmount} transferred to ${mother.boardType} Sub-Account`,
      status: "COMPLETED"
    });
    
    return subAccount;
  }

  async addToRebirthAccount(userId: number, boardType: string, amount: number, description: string): Promise<void> {
    // Get the currently active account for this board type
    const account = await this.getActiveRebirthAccount(userId, boardType);
    if (!account) return;
    
    const newBalance = Number(account.balance) + amount;
    await db.update(rebirthAccounts)
      .set({ balance: newBalance.toString() })
      .where(eq(rebirthAccounts.id, account.id));
    
    // Update total earnings in wallet
    const wallet = await this.getWallet(userId);
    if (wallet) {
      await this.updateWallet(userId, {
        totalEarnings: (Number(wallet.totalEarnings) + amount).toString()
      });
    }
    
    // Create transaction
    await this.createTransaction({
      userId,
      amount: amount.toString(),
      type: "LEVEL_INCOME",
      description: `${description} (${boardType} ${account.accountRole} Account)`,
      status: "COMPLETED"
    });
    
    // Check if threshold reached for auto-promotion to next board
    if (newBalance >= Number(account.threshold) && account.nextBoardType) {
      const existingNext = await this.getBoard(userId, account.nextBoardType);
      if (!existingNext) {
        const nextConfig = BOARD_CONFIG[account.nextBoardType];
        const remainingBalance = newBalance - nextConfig.entry;
        
        // If this is a SUB account, mark the new board entry as from a sub-account
        // This means: direct sponsor income goes to company, level income placement-based
        const isFromSub = account.accountRole === "SUB";
        
        // Create new board entry for next level FIRST
        const newBoard = await this.createBoard(userId, account.nextBoardType, isFromSub, account.id);
        
        const user = await this.getUser(userId);
        let placementParent: number | null = null;
        if (user?.sponsorId) {
          placementParent = await this.findPlacementParent(user.sponsorId, account.nextBoardType);
        }
        
        const siblingCount = placementParent ? await this.getMatrixChildrenCount(placementParent, account.nextBoardType) : 0;
        await this.addToMatrix(newBoard.id, userId, placementParent, siblingCount + 1, 1);
        
        await this.createTransaction({
          userId,
          amount: nextConfig.entry.toString(),
          type: "BOARD_ENTRY",
          description: `Auto-promotion to ${account.nextBoardType} Board from ${boardType} Account`,
          status: "COMPLETED"
        });
        
        // NOW CREATE A NEW SUB-ACCOUNT
        // Entry cost was deducted (conceptually spent on board entry)
        // Fresh Rs.5900 bonus is granted to the new SUB account for continued level income accumulation
        // Any remaining balance above entry fee is also transferred to SUB
        const nextNextBoard = getNextBoard(account.nextBoardType);
        const nextThreshold = nextNextBoard ? BOARD_CONFIG[nextNextBoard].entry : 100000;
        
        // Count existing sub accounts under this parent to determine sub-cycle
        const existingSubAccounts = await db.select().from(rebirthAccounts)
          .where(and(
            eq(rebirthAccounts.userId, userId),
            eq(rebirthAccounts.boardType, boardType as any),
            eq(rebirthAccounts.accountRole, "SUB")
          ));
        const subCycle = existingSubAccounts.length + 1;
        
        // Fresh bonus only applies to EV board (Rs.5900)
        // For other boards, only carry over the remainder (no fresh bonus)
        const freshBonus = boardType === "EV" ? 5900 : 0;
        const subAccountInitialBalance = freshBonus + Math.max(0, remainingBalance);
        
        // Create new SUB account with fresh bonus + carried-over remainder
        const [newSubAccount] = await db.insert(rebirthAccounts).values({
          userId,
          boardType: boardType as any,
          cycle: subCycle, // SUB accounts track their own sequence
          balance: subAccountInitialBalance.toString(),
          threshold: nextThreshold.toString(),
          nextBoardType: nextNextBoard as any,
          status: "ACTIVE",
          accountRole: "SUB",
          parentAccountId: account.id,
          isActive: true
        }).returning();
        
        // NOW mark current account as PROMOTED and inactive (after SUB is created)
        // Set balance to 0 since it was spent on the board entry (entry cost deducted)
        await db.update(rebirthAccounts)
          .set({ 
            balance: "0", // Entry cost deducted, remainder transferred to SUB
            status: "PROMOTED",
            isActive: false,
            promotedAt: new Date()
          })
          .where(eq(rebirthAccounts.id, account.id));
        
        // Record the entry cost deduction from the rebirth account
        await this.createTransaction({
          userId,
          amount: nextConfig.entry.toString(),
          type: "BOARD_ENTRY",
          description: `Entry fee Rs.${nextConfig.entry.toLocaleString()} deducted from ${boardType} ${account.accountRole} Account for ${account.nextBoardType} Board`,
          status: "COMPLETED"
        });
        
        // If fresh bonus is granted, track it in wallet (it's new income)
        if (freshBonus > 0 && wallet) {
          await this.updateWallet(userId, {
            totalEarnings: (Number(wallet.totalEarnings) + freshBonus).toString()
          });
        }
        
        const bonusDescription = freshBonus > 0 
          ? `Rs.${freshBonus.toLocaleString()} bonus + Rs.${Math.max(0, remainingBalance).toLocaleString()} remainder = Rs.${subAccountInitialBalance.toLocaleString()}`
          : `Rs.${subAccountInitialBalance.toLocaleString()} (carried over)`;
        
        await this.createTransaction({
          userId,
          amount: subAccountInitialBalance.toString(),
          type: "BOARD_ENTRY",
          description: `${bonusDescription} to new ${boardType} SUB Account (Cycle ${subCycle}) after promotion to ${account.nextBoardType}`,
          status: "COMPLETED"
        });
      }
    }
  }
  
  // Notification Methods
  async createNotification(title: string, message: string, createdBy: number): Promise<Notification> {
    const [notification] = await db.insert(notifications).values({
      title,
      message,
      createdBy
    }).returning();
    return notification;
  }
  
  async getNotifications(): Promise<Notification[]> {
    return await db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }
  
  async getUserNotifications(userId: number): Promise<any[]> {
    const result = await db
      .select({
        id: notifications.id,
        title: notifications.title,
        message: notifications.message,
        createdBy: notifications.createdBy,
        createdAt: notifications.createdAt,
        isRead: userNotifications.isRead,
        readAt: userNotifications.readAt
      })
      .from(notifications)
      .leftJoin(
        userNotifications,
        and(
          eq(userNotifications.notificationId, notifications.id),
          eq(userNotifications.userId, userId)
        )
      )
      .orderBy(desc(notifications.createdAt));
    
    return result.map(r => ({
      ...r,
      isRead: r.isRead || false,
      readAt: r.readAt || null
    }));
  }
  
  async markNotificationRead(userId: number, notificationId: number): Promise<void> {
    const [existing] = await db.select().from(userNotifications)
      .where(and(
        eq(userNotifications.userId, userId),
        eq(userNotifications.notificationId, notificationId)
      ));
    
    if (existing) {
      await db.update(userNotifications)
        .set({ isRead: true, readAt: new Date() })
        .where(eq(userNotifications.id, existing.id));
    } else {
      await db.insert(userNotifications).values({
        userId,
        notificationId,
        isRead: true,
        readAt: new Date()
      });
    }
  }
  
  async getUnreadNotificationCount(userId: number): Promise<number> {
    const result = await db
      .select({ id: notifications.id, isRead: userNotifications.isRead })
      .from(notifications)
      .leftJoin(
        userNotifications,
        and(
          eq(userNotifications.notificationId, notifications.id),
          eq(userNotifications.userId, userId)
        )
      );
    
    return result.filter(r => !r.isRead).length;
  }
}

export const storage = new DatabaseStorage();


import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);

  // Dashboard
  app.get(api.user.dashboard.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    
    const wallet = await storage.getWallet(userId);
    const finalWallet = wallet || await storage.createWallet(userId);
    
    // Get direct referrals count (only ACTIVE direct referrals with EV board)
    const directReferralCount = await storage.getActiveDirectReferralCount(userId);
    
    // Get user's boards with individual progress
    const userBoards = await storage.getUserBoards(userId);
    
    // Calculate per-board progress
    const boardsWithProgress = await Promise.all(
      userBoards.map(async (board) => {
        let progress = 0;
        let filled = 0;
        
        if (board.type === "EV") {
          // EV Board: progress based on active direct referrals
          filled = directReferralCount;
        } else {
          // Other boards: progress based on level 1 matrix positions filled
          filled = await storage.getMatrixChildrenCount(userId, board.type);
        }
        
        progress = Math.min(100, Math.round((filled / 6) * 100));
        
        return { ...board, progress, filled };
      })
    );
    
    // Get placements under user for EV board (to calculate level completion)
    const level1Count = await storage.getMatrixChildrenCount(userId, "EV");
    
    // Overall progress: based on 6 direct referrals needed
    const progress = Math.min(100, Math.round((directReferralCount / 6) * 100));

    res.json({
      wallet: finalWallet,
      activeBoards: boardsWithProgress,
      referralCount: directReferralCount,
      level1Placements: level1Count,
      progress: progress,
      totalTeamSize: level1Count,
    });
  });

  // Team
  app.get(api.user.team.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // Check if specific member ID is requested
    const memberId = req.query.memberId ? parseInt(req.query.memberId as string) : null;
    const targetId = memberId || (req.user as any).id;
    
    const referrals = await storage.getReferrals(targetId);
    
    // Get boards for each referral
    const teamWithBoards = await Promise.all(
      referrals.map(async (r) => {
        const userBoards = await storage.getUserBoards(r.id);
        return { 
          ...r, 
          level: 1,
          boards: userBoards.map(b => ({ type: b.type, status: b.status }))
        };
      })
    );
    
    res.json(teamWithBoards);
  });

  // Wallet Routes
  app.get(api.wallet.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const wallet = await storage.getWallet((req.user as any).id);
    res.json(wallet);
  });

  app.get(api.wallet.history.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const txns = await storage.getTransactions((req.user as any).id);
    res.json(txns);
  });

  app.post(api.wallet.withdraw.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const { amount, bankDetails } = api.wallet.withdraw.input.parse(req.body);
      const wallet = await storage.getWallet((req.user as any).id);
      
      if (!wallet || Number(wallet.mainBalance) < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Deduct balance
      await storage.updateWallet(wallet.userId, { 
        mainBalance: (Number(wallet.mainBalance) - amount).toString() 
      });

      // Create record
      const withdrawal = await storage.createWithdrawal(wallet.userId, amount, bankDetails);
      
      // Create transaction
      await storage.createTransaction({
        userId: wallet.userId,
        amount: amount.toString(),
        type: "WITHDRAWAL",
        description: "Withdrawal Request",
        status: "PENDING"
      });

      res.status(201).json(withdrawal);
    } catch (e) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Boards
  app.get(api.boards.list.path, async (req, res) => {
    // Return static list for now or fetch from DB
    res.json([]);
  });

  // Get current user's boards
  app.get("/api/user/boards", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    const userBoards = await storage.getUserBoards(userId);
    res.json(userBoards);
  });

  // Get matrix positions for user in a specific board type
  app.get("/api/matrix/:boardType", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const memberId = req.query.memberId ? parseInt(req.query.memberId as string) : null;
    const targetId = memberId || (req.user as any).id;
    const boardType = req.params.boardType;
    const matrixChildren = await storage.getMatrixChildren(targetId, boardType);
    res.json(matrixChildren);
  });

  // Get count of matrix children for a member
  app.get("/api/matrix/:boardType/count", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const memberId = req.query.memberId ? parseInt(req.query.memberId as string) : null;
    const targetId = memberId || (req.user as any).id;
    const boardType = req.params.boardType;
    const count = await storage.getMatrixChildrenCount(targetId, boardType);
    res.json({ count });
  });

  // Rebirth Accounts
  app.get("/api/rebirth-accounts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    const accounts = await storage.getRebirthAccounts(userId);
    res.json(accounts);
  });

  // Notifications
  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    const notifs = await storage.getUserNotifications(userId);
    res.json(notifs);
  });
  
  app.get("/api/notifications/unread-count", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    const count = await storage.getUnreadNotificationCount(userId);
    res.json({ count });
  });
  
  app.post("/api/notifications/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).id;
    const notificationId = parseInt(req.params.id);
    await storage.markNotificationRead(userId, notificationId);
    res.json({ success: true });
  });
  
  // Admin: Create notification
  app.post("/api/admin/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    if (!user.isAdmin) return res.status(403).json({ message: "Admin access required" });
    
    const { title, message } = req.body;
    if (!title || !message) {
      return res.status(400).json({ message: "Title and message are required" });
    }
    
    const notification = await storage.createNotification(title, message, user.id);
    res.json(notification);
  });
  
  // Admin: Get all notifications
  app.get("/api/admin/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = req.user as any;
    if (!user.isAdmin) return res.status(403).json({ message: "Admin access required" });
    
    const notifs = await storage.getNotifications();
    res.json(notifs);
  });

  app.post(api.boards.join.path, async (req, res) => {
     if (!req.isAuthenticated()) return res.sendStatus(401);
     const { type } = api.boards.join.input.parse(req.body);
     const userId = (req.user as any).id;

     // Use the new joinBoard method with income distribution
     const result = await storage.joinBoard(userId, type);
     
     if (!result.success) {
       return res.status(400).json({ message: result.message });
     }

     const board = await storage.getBoard(userId, type);
     res.json(board);
  });

  // Seeding Logic
  const existingUsers = await storage.getUserByUsername("admin");
  if (!existingUsers) {
    const hashedPassword = await import("./auth").then(m => (m as any).hashPassword("admin123").catch(() => "hashed_secret"));
    await storage.createUser({
      username: "admin",
      password: hashedPassword, // In real app, hash this!
      fullName: "Admin User",
      email: "admin@aghan.com",
      mobile: "9999999999",
      referralCode: "ADMIN01",
      isAdmin: true,
      sponsorId: null
    });
  }

  return httpServer;
}
